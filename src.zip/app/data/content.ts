
export const personalInfo = {
  name: "Sreenath A B",
  title: "AI Transformation & Process Automation Leader",
  tagline: "Driving AI-Led Operational Excellence & Scalable Automation Systems",
  location: "Chennai, India",
  contact: {
    email: "absreenath212436@gmail.com",
    linkedin: "https://linkedin.com/in/sreenath-ab",
    phone: "+91 9940296659"
  },
  summary: "I build AI-powered systems that eliminate manual workflows, optimize operational efficiency, and drive measurable business impact. With 8+ years in operations and digital transformation, I specialize in architecting scalable automation ecosystems using Agentic AI, RAG-based systems, and Human-in-the-Loop frameworks. My initiatives have delivered ₹73+ Lakhs annual cost savings while improving productivity by up to 90%.",
  philosophy: "I believe automation should not replace intelligence — it should amplify it. My approach combines AI systems with Human-in-the-Loop design to ensure scalability, quality, and measurable business impact."
};

export const keyImpacts = [
  { label: "Annual Cost Savings", value: "₹73+ Lakhs", icon: "TrendingUp" },
  { label: "AHT Reduction", value: "90%", icon: "Clock" },
  { label: "Workforce Optimization", value: "50%", icon: "Users" },
  { label: "Efficiency Gain", value: "75–100%", icon: "Zap" }
];

export const experience = [
  {
    role: "Team Manager",
    company: "Opendoor",
    period: "Nov 2023 – Present",
    description: "Leading a 45+ member operations team and a 5-member AI automation unit. Driving large-scale process transformation through AI initiatives.",
    achievements: [
      "Delivered ₹73+ Lakhs annual cost savings through headcount optimization and workflow redesign.",
      "Reduced AHT by up to 90% via Human-in-the-Loop AI workflows.",
      "Eliminated $1,800 recurring tool cost by system redesign.",
      "Improved reporting accuracy by 70% using AI-powered dashboards.",
      "Partnered with US-based stakeholders for transition and expansion initiatives."
    ]
  },
  {
    role: "Subject Matter Expert",
    company: "Opendoor",
    period: "Mar 2022 – Nov 2023",
    description: "Focused on process optimization, workflow redesign, and quality governance.",
    achievements: [
      "Redesigned multi-step workflows improving operational quality by 25%.",
      "Developed SOP optimization frameworks and automation logic.",
      "Built structured training modules supporting new process migrations.",
      "Ensured quality compliance through layered audits and RCA."
    ]
  },
  {
    role: "Senior Customer Associate",
    company: "Allsec Technologies",
    period: "Mar 2017 – Feb 2021",
    description: "Managed high-volume international client operations maintaining SLA compliance.",
    achievements: [
      "Contributed to automation initiatives improving resolution accuracy.",
      "Trained new team members on productivity and quality standards."
    ]
  }
];

export const projects = [
  {
    title: "Enterprise AI Automation Program",
    role: "Program Lead",
    tools: ["Zapier", "Gumloop", "Replit", "Extend.ai", "Gemini", "Figma"],
    problem: "High manual dependency across multiple operational streams leading to inefficiencies.",
    solution: "Designed end-to-end AI automation workflows replacing manual processes with Human-in-the-Loop AI systems.",
    impact: [
      "50%–100% manual workflow elimination",
      "90% reduction in Average Handling Time (AHT)",
      "Increased volume handling capacity",
      "$1,800 annual tool savings"
    ]
  },
  {
    title: "HOA Violation AI Agent",
    role: "Architect & Lead",
    tools: ["Agentic AI", "Custom Workflow"],
    problem: "Manual violation handling required ~40 minutes per task with a team of 8.",
    solution: "Built an AI agent to classify, validate, and process HOA violations using Human-in-the-Loop automation.",
    impact: [
      "Reduced AHT from 40 → 10 minutes",
      "Workforce reduced from 8 → 4 (50% savings)",
      "₹26 Lakhs annual workforce savings",
      "Improved SLA adherence & standardized quality"
    ]
  },
  {
    title: "HQI Process Automation",
    role: "Transformation Lead",
    tools: ["AI Workflow Redesign"],
    problem: "High manual workload and inefficiencies in quality review process.",
    solution: "Re-architected workflows using AI automation systems to streamline reviews.",
    impact: [
      "Team reduced from 13 → 6",
      "₹45.5 Lakhs annual savings",
      "75–100% efficiency increase",
      "Scalable processing model implemented"
    ]
  },
  {
    title: "AI Customer Feedback Intelligence",
    role: "Developer",
    tools: ["NLP", "Classification Engine"],
    problem: "Manual triage of customer feedback was slow and prone to errors.",
    solution: "Built an AI-based classification and routing engine to auto-triage feedback.",
    impact: [
      "Automated triage to appropriate teams",
      "Improved resolution SLA",
      "Reduced manual routing workload",
      "Increased response accuracy"
    ]
  },
  {
    title: "Intelligent Document Extraction",
    role: "Developer",
    tools: ["Document AI"],
    problem: "Manual multi-page document review was time-consuming and error-prone.",
    solution: "Developed an AI analyzer to replace manual review with an automated workflow.",
    impact: [
      "100% AI-driven review workflow",
      "Significant reduction in manual effort",
      "Improved audit consistency",
      "Enhanced data extraction accuracy"
    ]
  }
];

export const certifications = [
  {
    name: "Google Project Management Certificate",
    issuer: "Google",
    year: "2024–2025"
  },
  {
    name: "Generative AI for Project Managers",
    issuer: "IBM & SkillUp EdTech",
    year: "2025"
  },
  {
    name: "Google Prompting Essentials",
    issuer: "Google",
    year: "2025"
  },
  {
    name: "IBM RAG and Agentic AI",
    issuer: "IBM",
    year: "2025"
  }
];

export const skills = {
  ai_automation: ["Agentic AI", "RAG Systems", "Prompt Engineering", "Workflow Design", "Human-in-the-Loop"],
  operations: ["Lean Transformation", "SLA Optimization", "KPI Governance", "Transition Management"],
  leadership: ["Team Management (45+)", "AI Project Leadership", "Change Management", "Cross-Functional Collaboration"],
  tools: ["Zapier", "Gumloop", "Replit", "Extend.ai", "Gemini", "Figma"]
};
