
import { Section } from './ui/Section';
import { personalInfo } from '../data/content';
import { motion } from 'motion/react';
import { Quote } from 'lucide-react';

export function About() {
  return (
    <div id="about" className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
      <Section className="py-24">
        <div className="flex flex-col md:flex-row gap-16 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="w-full md:w-1/2"
          >
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight mb-8 text-slate-900 dark:text-white relative">
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-indigo-600 dark:from-blue-400 dark:to-indigo-400">
                Philosophy
              </span>
            </h2>
            <div className="relative p-8 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
              <Quote className="absolute top-6 left-6 w-8 h-8 text-blue-200 dark:text-slate-600 opacity-50" />
              <p className="relative z-10 text-xl font-light italic text-slate-700 dark:text-slate-300 leading-relaxed indent-6">
                {personalInfo.philosophy}
              </p>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="w-full md:w-1/2"
          >
            <h3 className="text-2xl font-semibold mb-6 text-slate-900 dark:text-white">
              About Me
            </h3>
            <div className="prose dark:prose-invert text-slate-600 dark:text-slate-400 text-lg leading-relaxed space-y-4">
              <p>
                As an <strong>AI Transformation Leader</strong>, I don't just manage processes—I reimagine them. With over 8 years of experience, I've transitioned from traditional operations management to architecting intelligent automation ecosystems.
              </p>
              <p>
                My expertise lies in identifying bottlenecks that others miss and deploying <strong>Agentic AI</strong> and <strong>Human-in-the-Loop</strong> solutions that solve them. I have successfully led cross-functional teams to deliver over <strong>₹73+ Lakhs</strong> in annual savings.
              </p>
              <p>
                I am passionate about bridging the gap between cutting-edge AI technology and practical business operations, ensuring that every automation we build translates directly to bottom-line impact.
              </p>
            </div>
            
            <div className="mt-8 pt-8 border-t border-slate-200 dark:border-slate-700">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="text-sm font-semibold uppercase tracking-wider text-slate-500 mb-2">Location</h4>
                  <p className="text-slate-900 dark:text-white font-medium">{personalInfo.location}</p>
                </div>
                <div>
                  <h4 className="text-sm font-semibold uppercase tracking-wider text-slate-500 mb-2">Focus</h4>
                  <p className="text-slate-900 dark:text-white font-medium">AI & Operations</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </Section>
    </div>
  );
}
