
import { Section } from './ui/Section';
import { experience } from '../data/content';
import { Briefcase, Calendar, ChevronRight } from 'lucide-react';
import { motion } from 'motion/react';

export function Experience() {
  return (
    <Section id="experience" className="py-24">
      <div className="text-center mb-16">
        <h2 className="text-3xl font-bold tracking-tight text-slate-900 dark:text-white sm:text-4xl">
          Professional Journey
        </h2>
        <p className="mt-4 text-lg text-slate-600 dark:text-slate-400">
          A track record of evolving from operations management to strategic AI leadership.
        </p>
      </div>

      <div className="relative border-l border-slate-200 dark:border-slate-800 ml-4 md:ml-10 space-y-12">
        {experience.map((job, index) => (
          <motion.div 
            key={index}
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="relative pl-8 md:pl-12"
          >
            <div className="absolute top-0 -left-1.5 md:-left-2 bg-white dark:bg-slate-900 p-1 rounded-full border border-blue-200 dark:border-blue-900 shadow-sm z-10">
              <div className="w-2 h-2 md:w-3 md:h-3 rounded-full bg-blue-600 dark:bg-blue-500 animate-pulse" />
            </div>
            
            <div className="flex flex-col md:flex-row md:items-start md:justify-between mb-4">
              <div>
                <h3 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2 group">
                  {job.role}
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-blue-500 transition-colors" />
                </h3>
                <div className="flex items-center gap-2 text-sm font-medium text-slate-500 dark:text-slate-400 mt-1">
                  <Briefcase className="w-4 h-4" />
                  <span>{job.company}</span>
                  <span className="mx-2 text-slate-300">•</span>
                  <Calendar className="w-4 h-4" />
                  <span>{job.period}</span>
                </div>
              </div>
            </div>

            <p className="text-slate-600 dark:text-slate-300 mb-4 text-base leading-relaxed max-w-3xl">
              {job.description}
            </p>

            <ul className="space-y-3">
              {job.achievements.map((achievement, i) => (
                <li key={i} className="flex items-start gap-3 text-sm md:text-base text-slate-600 dark:text-slate-400">
                  <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-blue-500 flex-shrink-0" />
                  <span>{achievement}</span>
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </Section>
  );
}
