
import { Section } from './ui/Section';
import { skills } from '../data/content';
import { BadgeCheck, Brain, Cog, Database, LayoutTemplate } from 'lucide-react';
import { motion } from 'motion/react';

const iconMap = {
  ai_automation: Brain,
  operations: Cog,
  leadership: BadgeCheck,
  tools: LayoutTemplate,
};

export function Skills() {
  return (
    <Section id="skills" className="py-24 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
      <div className="text-center mb-16">
        <h2 className="text-4xl font-bold tracking-tight text-slate-900 dark:text-white mb-4">
          Technical Arsenal
        </h2>
        <p className="max-w-2xl mx-auto text-lg text-slate-600 dark:text-slate-400">
          A comprehensive suite of tools and methodologies powering intelligent automation.
        </p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
        {Object.entries(skills).map(([category, items], index) => {
          const Icon = iconMap[category as keyof typeof iconMap] || Brain;
          return (
            <motion.div
              key={category}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-slate-50 dark:bg-slate-800 p-6 rounded-2xl shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-center gap-3 mb-6">
                <div className="p-2 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-lg">
                  <Icon className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-semibold capitalize text-slate-900 dark:text-white">
                  {category.replace('_', ' ')}
                </h3>
              </div>
              <ul className="space-y-3">
                {items.map((skill) => (
                  <li key={skill} className="flex items-center gap-2 text-slate-600 dark:text-slate-300 group">
                    <div className="w-1.5 h-1.5 rounded-full bg-slate-300 dark:bg-slate-600 group-hover:bg-blue-500 transition-colors" />
                    <span className="text-sm font-medium">{skill}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          );
        })}
      </div>
    </Section>
  );
}
