
import { Section } from './ui/Section';
import { personalInfo } from '../data/content';
import { Mail, Linkedin, Phone } from 'lucide-react';
import { motion } from 'motion/react';

export function Contact() {
  return (
    <Section id="contact" className="py-24 bg-slate-900 text-white border-t border-slate-800">
      <div className="max-w-4xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl md:text-5xl font-bold tracking-tight mb-8">
            Ready to Transform Your Operations?
          </h2>
          <p className="text-xl text-slate-300 mb-12 max-w-2xl mx-auto">
            Let's discuss how AI-driven automation can reduce costs and scale your business efficiency.
          </p>
          
          <div className="flex flex-col md:flex-row gap-6 justify-center items-center">
            <a
              href={`mailto:${personalInfo.contact.email}`}
              className="group flex items-center gap-3 px-8 py-4 bg-blue-600 hover:bg-blue-500 rounded-full text-lg font-medium transition-all shadow-lg hover:shadow-blue-500/25"
            >
              <Mail className="w-5 h-5 group-hover:scale-110 transition-transform" />
              <span>{personalInfo.contact.email}</span>
            </a>
            
            <a
              href={personalInfo.contact.linkedin}
              target="_blank"
              rel="noopener noreferrer"
              className="group flex items-center gap-3 px-8 py-4 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-full text-lg font-medium transition-all"
            >
              <Linkedin className="w-5 h-5 group-hover:scale-110 transition-transform" />
              <span>Connect on LinkedIn</span>
            </a>
          </div>

          <div className="mt-16 pt-16 border-t border-slate-800 text-sm text-slate-500">
            <p>&copy; {new Date().getFullYear()} {personalInfo.name}. All rights reserved.</p>
            <p className="mt-2">Built with React, Tailwind CSS & AI.</p>
          </div>
        </motion.div>
      </div>
    </Section>
  );
}
