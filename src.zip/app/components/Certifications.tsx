
import { Section } from './ui/Section';
import { certifications } from '../data/content';
import { Award, BookOpen, Scroll } from 'lucide-react';
import { motion } from 'motion/react';

export function Certifications() {
  return (
    <Section id="certifications" className="py-24 bg-slate-50 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
      <div className="text-center mb-16">
        <h2 className="text-4xl font-bold tracking-tight text-slate-900 dark:text-white mb-4">
          Professional Certifications
        </h2>
        <p className="max-w-2xl mx-auto text-lg text-slate-600 dark:text-slate-400">
          Continuous learning and validation of expertise in AI and project management.
        </p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
        {certifications.map((cert, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="flex flex-col items-center text-center p-6 bg-white dark:bg-slate-800 rounded-2xl shadow-sm hover:shadow-lg transition-all border border-slate-100 dark:border-slate-700"
          >
            <div className="w-16 h-16 mb-4 rounded-full bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 flex items-center justify-center">
              <Award className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-2 leading-tight">
              {cert.name}
            </h3>
            <div className="mt-auto pt-4 flex flex-col gap-1 w-full text-sm text-slate-500 dark:text-slate-400">
              <span className="font-medium text-slate-900 dark:text-slate-200">{cert.issuer}</span>
              <span>{cert.year}</span>
            </div>
          </motion.div>
        ))}
      </div>
    </Section>
  );
}
