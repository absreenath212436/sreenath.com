
import { Section } from './ui/Section';
import { keyImpacts } from '../data/content';
import { TrendingUp, Clock, Users, Zap } from 'lucide-react';
import { motion } from 'motion/react';

const iconMap: Record<string, React.ComponentType<any>> = {
  TrendingUp,
  Clock,
  Users,
  Zap,
};

export function Stats() {
  return (
    <div className="bg-slate-50 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
      <Section className="py-12 md:py-16">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-12">
          {keyImpacts.map((stat, index) => {
            const Icon = iconMap[stat.icon] || TrendingUp;
            return (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="text-center group"
              >
                <div className="inline-flex items-center justify-center p-3 mb-4 rounded-2xl bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 group-hover:scale-110 transition-transform">
                  <Icon className="w-6 h-6 md:w-8 md:h-8" />
                </div>
                <div className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-white mb-2 tracking-tight">
                  {stat.value}
                </div>
                <div className="text-sm md:text-base text-slate-500 dark:text-slate-400 font-medium uppercase tracking-wide">
                  {stat.label}
                </div>
              </motion.div>
            );
          })}
        </div>
      </Section>
    </div>
  );
}
